# ?? Detection of Thyroid Nodules using Deep Learning

This project explores the use of **Deep Learning (LSTM & GRU)** and **Machine Learning (KNN & Random Forest)** to detect thyroid disorders using structured medical data. Models are trained, evaluated, and compared to identify the most accurate diagnostic approach.

---

## ?? Project Overview

* Builds predictive models for thyroid disorder detection
* Compares RNN models (LSTM, GRU) with ML models
* Includes full preprocessing, training, evaluation, and visualisations
* Achieves up to **99% accuracy** using Random Forest

---

## ?? Results (Summary)

| Model             | Accuracy   |
| ----------------- | ---------- |
| LSTM              | 92.40%     |
| GRU               | 92.40%     |
| KNN               | 91.24%     |
| **Random Forest** | **99.07%** |

**Best model: Random Forest**

---

## ?? Repository Contents

```
README.md  
Thyroid_detection.ipynb  
Detection_of_Thyroid_Nodules_Using_Deep_Learning.pptx  
requirements.txt  
.gitignore  
data/  
models/  
results/
```

---

## ?? How to Run

### 1?? Install dependencies

```bash
pip install -r requirements.txt
```

### 2?? Run Notebook

```bash
jupyter notebook Thyroid_detection.ipynb
```

---

## ?? Technologies Used

* Python
* TensorFlow / Keras
* Scikit-Learn
* Pandas, NumPy
* Matplotlib, Seaborn

---

## ?? Author

**Vishal Kumar Reddy Gudla**
MSc Computer Science Engineering
Coventry University

---

If you want, I can generate an even **shorter** README, or a **minimal one-page version**.

?? Detection of Thyroid Nodules using Deep Learning
This project explores the use of Deep Learning (LSTM & GRU) and Machine Learning (KNN & Random Forest) to detect thyroid disorders using structured medical data. Models are trained, evaluated, and compared to identify the most accurate diagnostic approach.

?? Project Overview
* Builds predictive models for thyroid disorder detection
* Compares RNN models (LSTM, GRU) with ML models
* Includes full preprocessing, training, evaluation, and visualisations
* Achieves up to 99% accuracy using Random Forest

?? Results (Summary)
ModelAccuracyLSTM92.40%GRU92.40%KNN91.24%Random Forest99.07%Best model: Random Forest

?? Repository Contents
README.md  
Thyroid_detection.ipynb  
Detection_of_Thyroid_Nodules_Using_Deep_Learning.pptx  
requirements.txt  
.gitignore  
data/  
models/  
results/

?? How to Run
1?? Install dependencies
pip install -r requirements.txt
2?? Run Notebook
jupyter notebook Thyroid_detection.ipynb

?? Technologies Used
* Python
* TensorFlow / Keras
* Scikit-Learn
* Pandas, NumPy
* Matplotlib, Seaborn


